/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana08_trabajo_technoworld;

/**
 *
 * @author joseph267
 */
public class menu {
    
    
        public void menu(){
        proceso class1 = new proceso();
    
        //class1.Registrar_cliente();
        class1.Registrar_venta();
        class1.Mostrar_factura();
        
    
        
    }
}
