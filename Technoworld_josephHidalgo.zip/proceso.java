/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana08_trabajo_technoworld;

import javax.swing.JOptionPane;

/**
 *
 * @author joseph267
 */
public class proceso {
    public String cliente;
    public double valor = 0;
    public double descuento;
    public String metodoPago;
    
    
    public double Registrar_venta(){
        
    int cantidad;   
    cantidad = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de  productos que desea:"));
    
    
    for (int i = 1;i <=cantidad;i++){
    
    
    int  menu;
    int articulos;
    int precio = 0;
    articulos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de producto que desea: /n"+
                                   "1.computadora = 70.000 \n"+
                                   "2. Labtop = 50.000 \n"+
                                   "3. teclado= 20.000\n"+
                                   "4. mouse = 10.000 \n" + "5.monitor = 30.000 \n" + "6.impresora = 30.000 \n"));
    //articulos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de producto que desea:"));
    
     if (articulos == 1) {
              precio = 70000;      
          }
          else if (articulos == 2){
              precio = 50000;   
          
          }
          else if (articulos == 3){
              precio = 20000;   
          
          }
          else if (articulos == 4){
              precio = 10000;   
          
          }
          else if (articulos == 5){
              precio = 30000;   
          
          }
          else if (articulos == 6){
              precio = 30000;   
          
          }
          else{
          JOptionPane.showMessageDialog(null,"articulo invalido");
          }
     
           valor = valor + precio;
           System.out.print(valor);
                
          
          
    
    
    }
    
          // Aplicar descuento y calcular el IVA
        
        String metodoPago = JOptionPane.showInputDialog("Ingrese el método de pago (efectivo o tarjeta):");
        if (metodoPago.equalsIgnoreCase("efectivo")) {
            descuento = valor * 0.15; // Descuento del 15% en efectivo
        } else if (metodoPago.equalsIgnoreCase("tarjeta")) {
            descuento = valor * 0.05; // Descuento del 5% con tarjeta
        } else {
            JOptionPane.showMessageDialog(null, "Método de pago inválido");
            
        }

        valor = valor - descuento;
        double iva = valor * 0.13;
        valor = valor - iva;
        
        return valor;
    
    }
    
     public void Registrar_cliente(){
         
    String Nombre;
    String Apellido;
    int Cedula;
    String Direccion;
    String Correo;
    
     
         
    
        Nombre = JOptionPane.showInputDialog("Ingrese el nombre del cliente:");
        Apellido = JOptionPane.showInputDialog("Ingrese el Apellido:");
        Cedula = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cedula:"));
        Direccion = JOptionPane.showInputDialog("Ingrese la dirreccion del cliente:");
        Correo =  JOptionPane.showInputDialog("Ingrese el correo electronico:");    
        
       
        
        cliente = "Nombre: " + Nombre + "\n" +
                  "Apellido: " + Apellido + "\n" +
                  "Cedula: " + Cedula + "\n" +
                  "Direccion: " + Direccion + "\n" +
                  "Correo Electronico: " + Correo;
       
        
        
    
    }
     
     public void Mostrar_factura(){
         
             JOptionPane.showMessageDialog(null, "Factura: \n" +
                                            "\n" +
                                            "Cliente: \n" +
                                            cliente + "\n" +"Descuento por efectivo 15% - tarjeta 5%" +"\n" +"IVA 13% \n"+
                                            "Valor total: " + valor + "\n");
    
        
         
     }
    
}
